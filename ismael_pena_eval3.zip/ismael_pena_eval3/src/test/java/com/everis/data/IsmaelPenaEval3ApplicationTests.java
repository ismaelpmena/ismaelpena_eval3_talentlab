package com.everis.data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsmaelPenaEval3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
