package com.everis.data.services;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.everis.data.models.Venta;
import com.everis.data.repositories.VentaRepository;

@Service
public class VentaService {
	@Autowired
	VentaRepository vr;

	public List<Venta> findAll() {
		return vr.findAll();
	}

	public void save(Venta venta) {
		vr.save(venta);
	}

	public void insertarVenta(@Valid Venta venta) {
		System.out.println("venta ingresada");
		vr.save(venta);
	}

	public void eliminarVenta(Long id) {
		vr.deleteById(id);		
	}


}
