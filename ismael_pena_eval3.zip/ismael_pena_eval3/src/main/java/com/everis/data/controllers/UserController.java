package com.everis.data.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.everis.data.models.User;
import com.everis.data.services.UserService;

@Controller
public class UserController {
	
	@Autowired // se ahorra el definir una instancia
	UserService us;
	
	@RequestMapping("/login")//relaciona este metodo con el jsp
	public String login() {
		return "login.jsp";
	}
	
	@RequestMapping("/registro")
	public String registro(@ModelAttribute("user") User user) {
		return "registro.jsp";
	}
	
	@RequestMapping("/ingresar")
	public String ingresar(@RequestParam("email") String email,
			@RequestParam("password") String password, HttpSession session) {
		boolean exiteUsuario = us.validarUser(email, password);
		if(exiteUsuario) {
			User user = us.findByEmail(email);//se busca y luego se guarda la sesion
			session.setAttribute("userId", user.getId());
			return "home.jsp";
		}
		return "login.jsp";
	}
	
	@RequestMapping("/registrar")
	public String registrar(@Valid @ModelAttribute("user") User user) {
		us.save(user);
		return "login.jsp";
	}
	
	@RequestMapping("/home")
	public String home(HttpSession session){
		if(session.getAttribute("userId")!=null) {// validacion
			return "home.jsp";
		}
		return "redirect:/login";
		
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		
		if(session.getAttribute("userId")!=null) {
			session.invalidate();//cerrar sesion
		}
		return "redirect:/login";
	}
	
	
}
