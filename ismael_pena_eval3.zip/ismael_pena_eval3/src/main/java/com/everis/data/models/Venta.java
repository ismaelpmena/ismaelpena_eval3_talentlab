package com.everis.data.models;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="ventas")
public class Venta {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String nombre;
	private Integer total_ventas;
	
	
	//relacion 1 a muchos
		@OneToMany(mappedBy = "venta",fetch = FetchType.LAZY)
		private List<Producto> productos;
	

	
	@Column(updatable=false)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date createdAt;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date updatedAt;
	

	public Venta() {
		super();
	}

	public Venta(Long id, String nombre, Integer total_ventas) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.total_ventas = total_ventas;
	}

	
	

	
	

	public Venta(String nombre) {
		super();
		this.nombre = nombre;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Integer getTotal_ventas() {
		return total_ventas;
	}

	public void setTotal_ventas(Integer total_ventas) {
		this.total_ventas = total_ventas;
	}

	@PrePersist 
	protected void onCreate(){
	this.createdAt = new Date();
	}
	
	@PreUpdate 
	protected void onUpdate(){
	this.updatedAt = new Date();
	}
	
}
